package com.devst.loginbasico;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AccesoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acceso);

        String usuario = getIntent().getStringExtra("usuario");
        TextView tvBienvenido = findViewById(R.id.tvBienvenido);
        tvBienvenido.setText("¡Bienvenido, " + usuario + "!");
    }
}
