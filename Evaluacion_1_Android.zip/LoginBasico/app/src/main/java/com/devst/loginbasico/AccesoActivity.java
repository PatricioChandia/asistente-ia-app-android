package com.devst.loginbasico;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class AccesoActivity extends AppCompatActivity {
    private EditText etComentario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_acceso);

        etComentario = findViewById(R.id.etComentario);

        findViewById(R.id.btnEnviarEvaluacion).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {enviarEvaluacion();
            }
        });

        findViewById(R.id.btnCerrarSesion).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void enviarEvaluacion() {

        String comentario = etComentario.getText().toString().trim();

        String mensaje = "Evaluación enviada";

        Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show();
        // Limpiar el formulario después de enviar
        limpiarFormulario();
    }

    private void limpiarFormulario() {
        // Limpiar comentario
        etComentario.setText("");
    }
}