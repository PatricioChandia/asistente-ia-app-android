package com.devst.loginbasico;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity { /* Herencia  */

    private EditText email, password;
    private Button btnLogin;
    private TextView registrar;

    private static final String DEMO_EMAIL = "tiffanybaron1998@gmail.com";
    private static final String DEMO_PASS = "123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        email     = findViewById(R.id.email);
        password  = findViewById(R.id.password);
        btnLogin  = findViewById(R.id.btnLogin);
        registrar = findViewById(R.id.registrar);

        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickCrear(v);
            }
        });
    }

    public void onClickEntrar(View view) {
        String user = email.getText().toString().trim();
        String pass = password.getText().toString();

        if (user.isEmpty()) {
            Toast.makeText(this,"El campo de usuario está vacío", Toast.LENGTH_SHORT).show();
            email.requestFocus();
            return;
        }
        if (pass.isEmpty()) {
            Toast.makeText(this,"El campo de contraseña está vacío", Toast.LENGTH_SHORT).show();
            password.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(user).matches()) {
            Toast.makeText(this, "Formato de correo inválido", Toast.LENGTH_SHORT).show();
            email.requestFocus();
            return;
        }

        boolean emailOk = user.equalsIgnoreCase(DEMO_EMAIL);
        boolean passOk  = pass.equals(DEMO_PASS);

        if (emailOk && passOk) {
            Intent intent = new Intent(this, AccesoActivity.class);
            intent.putExtra("usuario", user);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Credenciales Incorrectas", Toast.LENGTH_SHORT).show();
        }
    }

    public void onClickCrear(View view) {
        Intent intent = new Intent(MainActivity.this, RegistroActivity.class);
        startActivity(intent);
    }
}